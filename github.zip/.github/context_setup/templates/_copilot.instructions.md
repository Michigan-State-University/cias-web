---
applyTo: "**"
---
# CRITICAL RULES
- **ALWAYS** BEFORE ANY TERMINAL OPERATION FOLLOW THE INSTRUCTIONS IN THE [local setup instructions](/.github/instructions/local_setup.instructions.md)
- NEVER UPDATE CONFLUENCE PAGES
- NEVER UPDATE JIRA TICKETS

# Copilot Instructions for {{PROJECT_NAME}}

## Project Overview

{{brief project description based on the .github/context_setup/initial_context.md file}}

## Tech Stack & Architecture

- **Runtime**: {{information about the runtime, e.g., Node.js 18.x}}
- **Language**: {{information about the programming language of the current repository, e.g., TypeScript with strict type checking}}
- **Framework**: {{information about the main framework used with specified version, e.g., Serverless Framework for AWS Lambda, Ruby on Rails version 7.2.0}}
- **Database**: {{information about the database and ORM used, e.g., PostgreSQL with TypeORM}}
- **Queue System**: {{information about the queue system used if any, e.g., AWS SQS, Sidekiq}}
- **Authentication**: {{information about the authentication method used, e.g., custom JWT-based authentication, OAuth2, Devise}}
- **Infrastructure**: {{information about the infrastructure, e.g., AWS Lambda, EC2 instances, Docker containers}}
- **Testing**: {{information about the testing framework used, e.g., Jest with ts-jest for TypeScript, RSpec for Ruby on Rails}}
- **Deployment**: {{information about the deployment method, e.g., Serverless Framework, Capistrano, Heroku}}
- **Local Development**: {{any useful information about local development setup, e.g., Localstack for AWS services simulation, Docker Compose for local PostgreSQL}}

## Code Standards & Conventions

### File Structure & Organization

{{list of important directories and their purposes and already existing conventions}}

### Naming Conventions

{{scan the repository to detect any existing naming conventions for files, variables, functions, classes, etc.; name them here}}

### Linters & Formatters

{{scan the repository to detect any existing linters or formatters defined in the project already (like ESLint, Prettier, RuboCop, etc.); read their configurations and summarize the main rules here}}

### Database & ORM Guidelines

{{try to understand how the database is structured and how the ORM is used; summarize the main patterns and conventions here; e.g., how to define models, relationships, migrations, indexing, etc.}}

# Development Guidelines

Remember to always consider scalability, security, and maintainability when implementing new features. Follow the established patterns and maintain consistency with the existing codebase.