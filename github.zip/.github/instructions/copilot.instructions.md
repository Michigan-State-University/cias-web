---
applyTo: "**"
---

# CRITICAL RULES
- **ALWAYS** BEFORE ANY TERMINAL OPERATION FOLLOW THE INSTRUCTIONS IN THE [local setup instructions](/.github/instructions/local_setup.instructions.md)
- **NEVER** UPDATE CONFLUENCE PAGES
- **NEVER** UPDATE JIRA TICKETS

# Copilot Instructions for CIAS WEB

## Project Overview

CIAS (Computer-Based Intervention Authoring System) is a comprehensive digital platform designed to accelerate digital intervention science by enabling researchers and healthcare professionals to create, manage, and deliver multi-session behavioral health interventions without requiring any coding expertise. The platform addresses the critical need for accessible tools that allow the development of evidence-based digital health interventions while maintaining robust data collection and analysis capabilities.

The primary users are academic researchers at universities and non-profit research institutions conducting behavioral health studies, clinical researchers developing evidence-based interventions for healthcare settings, healthcare professionals seeking to implement digital therapeutic solutions, and research teams requiring collaborative intervention development capabilities.

## Tech Stack & Architecture

  - **Runtime**: Node.js 18.x
  - **Language**: TypeScript, JavaScript (ES2022+), and JSX
  - **Framework**: React 18 with Vite for high-performance development and builds
  - **State Management**: Redux Toolkit using the "ducks" or feature-sliced pattern for scalable state management
  - **Routing**: React Router v6 for client-side navigation and route management
  - **Styling**: Sass (SCSS) for custom styles, integrated with Material-UI (MUI) v5 for the core component library
  - **API Communication**: Axios for making HTTP requests to the CIAS API, with centralized instance configuration
  - **Infrastructure**: Docker containerization with docker-compose for local development, and deployment of static assets to AWS S3/CloudFront in production
  - **Testing**: Vitest for the test runner, React Testing Library for component testing, and MSW (Mock Service Worker) for robust API mocking
  - **Deployment**: GitHub Actions CI/CD pipeline with Node.js 18.x, automated testing, linting, and build processes
  - **Local Development**: Docker Compose with Vite's Hot Module Replacement (HMR) for instant feedback, and `.env` files for environment configuration

## Code Standards & Conventions

### File Structure & Organization

  - **src/api/**: Axios instance configuration and API endpoint definitions
  - **src/app/**: Core application setup, including the Redux store and router configuration
  - **src/assets/**: Static assets like images, fonts, and global stylesheets
  - **src/components/**: Shared, reusable React components (e.g., buttons, inputs, modals)
  - **src/constants/**: Application-wide constants, such as route paths or enums
  - **src/features/**: Feature-based modules containing slices, components, and hooks specific to a domain (e.g., `auth`, `interventions`)
  - **src/hooks/**: Custom, reusable React hooks
  - **src/pages/**: Top-level components that correspond to application routes
  - **src/store/**: Redux store configuration and root reducers
  - **src/styles/**: Global SCSS files, including variables, mixins, and resets
  - **src/utils/**: General utility functions used across the application

### Naming Conventions

  - **Files & Folders**: Kebab-case for general folders (e.g., `user-session`), PascalCase for component files (e.g., `InterventionEditor.jsx`), and camelCase for hook/utility files (e.g., `useAuth.js`)
  - **Components**: PascalCase (e.g., `UserSession`, `InterventionAccess`)
  - **Methods, Functions & Variables**: camelCase (e.g., `createIntervention`, `sessionData`)
  - **Constants**: SCREAMING\_SNAKE\_CASE (e.g., `API_ROUTES`, `DEFAULT_THEME`)
  - **CSS/SCSS Classes**: Kebab-case, preferably following BEM (Block, Element, Modifier) principles where applicable (e.g., `.card__title--active`)

### Linters & Formatters

  - **ESLint**: Enforced with a strict ruleset (`.eslintrc.cjs`) covering React best practices, hooks, and general JavaScript quality
  - **Prettier**: Automatic code formatting (`.prettierrc`) to ensure a consistent style across the entire codebase
  - **Code Style**: Functional components with React Hooks are preferred over class components. All new components should be written this way.

### Component & Logic Guidelines

  - **Component Design**: Components should be small, focused, and reusable. Use Material-UI (MUI) for base elements and compose them to build complex UIs.
  - **State Management**: All global or shared state must be managed through Redux Toolkit. Use `createSlice` to define state, reducers, and actions. Use selectors to read data from the store.
  - **Local State**: Use `useState` and `useReducer` for state that is strictly local to a single component (e.g., form input values).
  - **Asynchronous Operations**: Handle API calls and other side effects using Redux Thunks created with `createAsyncThunk`.
  - **Styling**: Leverage MUI's theming capabilities. For custom styling, use SCSS modules or styled-components approach to keep styles scoped to their respective components.
  - **Forms**: Use controlled components for handling form state.
  - **Testing**: Write tests for components using React Testing Library, focusing on user behavior and accessibility rather than implementation details. Use MSW to mock API endpoints for predictable test results.

# Development Guidelines

Remember to always consider user experience, accessibility, and performance when implementing new features. Follow the established patterns like the feature-sliced Redux structure and maintain consistency with the existing codebase. Build reusable components, ensure proper test coverage with Vitest and RTL, and document complex logic where necessary. Ensure all user-facing text is managed in a way that supports future internationalization.
