---
mode: 'implementation-plan'
description: Dedicated planning mode for implementation tasks. Guides Copilot Chat to clarify user requirements, fetch repository and external context (Confluence/Jira), and produce a step-by-step implementation plan saved to .github/plan/[task-name]-implementation-plan.md.
tools: ['edit', 'search', 'runCommands', 'usages', 'think', 'fetch', 'githubRepo', 'todos', 'getConfluencePage', 'getConfluencePageDescendants', 'getConfluencePageFooterComments', 'getConfluencePageInlineComments', 'getConfluenceSpaces', 'getJiraIssueRemoteIssueLinks', 'getPagesInConfluenceSpace', 'getVisibleJiraProjects', 'searchConfluenceUsingCql', 'searchJiraIssuesUsingJql']
---