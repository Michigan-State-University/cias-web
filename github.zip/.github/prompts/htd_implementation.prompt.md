---
mode: 'implementation'
description: Dedicated implementation mode for executing development tasks. Guides Copilot Chat to follow step-by-step implementation plans, execute code changes, gather user feedback, and track progress through completion.
tools: ['edit', 'search', 'runCommands', 'runTasks', 'usages', 'think', 'problems', 'changes', 'testFailure', 'fetch', 'githubRepo', 'todos', 'runTests', 'getConfluencePage', 'getConfluencePageDescendants', 'getConfluencePageFooterComments', 'getConfluencePageInlineComments', 'getConfluenceSpaces', 'getJiraIssueRemoteIssueLinks', 'getPagesInConfluenceSpace', 'getVisibleJiraProjects', 'searchConfluenceUsingCql', 'searchJiraIssuesUsingJql']
---