# GitHub Copilot Setup Instructions

Please help me set up GitHub Copilot instructions for this repository by following these steps:

## Step 1: Read Template File
First, read the template file located at [_copilot.instructions.md](/.github/context_setup/templates/_copilot.instructions.md) and understand its structure.

## Step 2: Analyze Current Repository
Analyze the current repository to gather the following information:

### Project Information
- Read [initial_context.md](/.github/context_setup/initial_context.md) for project description
- Determine the project name from repository structure or package.json/similar files

### Tech Stack Analysis
- **Runtime**: Identify the runtime environment (e.g., Node.js version from .nvmrc, package.json engines)
- **Language**: Determine primary programming language and version/configuration
- **Framework**: Identify main framework and version from package.json, Gemfile, requirements.txt, etc.
- **Database**: Look for database configuration in config files, environment variables, or ORM setup
- **Queue System**: Check for queue system usage (AWS SQS, Redis, Sidekiq, etc.)
- **Authentication**: Identify authentication method from code patterns or dependencies
- **Infrastructure**: Determine deployment target (AWS Lambda, EC2, Docker, etc.)
- **Testing**: Find testing framework from package.json, Gemfile, or test directory structure
- **Deployment**: Identify deployment method from CI/CD files, scripts, or config
- **Local Development**: Find local development setup from README, docker-compose, or scripts

### Code Standards Analysis
- **File Structure**: Map important directories and their purposes
- **Naming Conventions**: Scan existing code to identify patterns for files, variables, functions, classes
- **Linters & Formatters**: Find and read configuration files (.eslintrc, .prettierrc, .rubocop.yml, etc.)
- **Database & ORM**: Analyze model definitions, migration patterns, and relationship structures

## Step 3: Create Instructions File
1. Create the directory `/.github/instructions/` if it doesn't exist
2. Create a new file: `/.github/instructions/copilot.instructions.md`
3. Copy the content from the template file
4. Replace all placeholders marked with `{{}}` with the actual analyzed content:
   - `{{PROJECT_NAME}}` → actual project name
   - `{{brief project description...}}` → content from initial_context.md
   - `{{information about the runtime...}}` → detected runtime info
   - `{{information about the programming language...}}` → detected language info
   - `{{information about the main framework...}}` → detected framework info
   - And so on for all other placeholders...

## Step 4: Validation
After creating the file, please:
- Ensure all `{{}}` placeholders have been replaced with actual content
- Verify the file structure and syntax are correct
- Confirm the instructions are relevant to the current repository

## Expected Output
The final `/.github/instructions/copilot.instructions.md` file should contain:
- All original template content
- All placeholders replaced with repository-specific information
- No remaining `{{}}` markers
- Accurate and relevant instructions for GitHub Copilot to assist with this specific project

Please proceed with these steps and let me know if you need any clarification or encounter any issues during the process.